const businessDetails = {
  imageSrc:
    "https://lh3.googleusercontent.com/places/ANXAkqHTDyTk2Qt27v3cA7ViRk4MbF0C1CAPLv0TxQ3tKL6OxThM4KyzcH0g6fEN8d1R0M6qwIPhPovwKPCxcaHX_Bs1-AXflwsDGUE=s4800-h400",
  name: "MarginOtto Pizzeria",
  address: "Minato City, Roppongi, 7-chōme−12−23 六本木フォルトゥーナ 2F",
  category: "Italian",
  rating: 4.5,
  reviewCount: 90,
};

export default businessDetails;
