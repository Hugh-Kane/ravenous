import { Heading } from "@chakra-ui/react";
import React from "react";

function Top() {
  return <Heading>Ravenous</Heading>;
}

export default Top;
